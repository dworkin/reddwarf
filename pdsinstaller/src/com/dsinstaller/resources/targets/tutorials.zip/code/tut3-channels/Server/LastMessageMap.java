

package com.sun.darkstar.tutorial.introduction;

import com.sun.sgs.app.ManagedObject;
import java.io.Serializable;
import java.util.HashMap;

/**
 * This is a hash-map of all the previous values.  Its purpose is to wrap
 * a hashmap into a ManagedObject.  Note that it is advisable to use the
 * ScalableHashMap provided by the Project Darkstar utility package.
 * 
 * @author Chris Scalabini
 */
public class LastMessageMap implements ManagedObject, Serializable {
    
    public HashMap<String, String> map;
    
    public LastMessageMap()
    {
        map = new HashMap<String, String>();
    }
}
