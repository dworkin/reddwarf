
package com.sun.darkstar.tutorial.introduction;

import com.sun.sgs.app.AppContext;
import com.sun.sgs.app.ClientSessionListener;
import com.sun.sgs.app.ClientSession;
import com.sun.sgs.app.ManagedObject;
import com.sun.sgs.app.ManagedReference;
import java.io.Serializable;
import java.nio.ByteBuffer;

/**
 * This is the TutorialClientListener for the Quick-Start tutorials.
 * @author Chris Scalabrini
 */
public class TutorialClientListener implements ClientSessionListener, ManagedObject, Serializable {

    ManagedReference<ClientSession> session = null;
    ManagedReference<LastMessageMap> lastMessageMap; 
    
   /**
    * This method acts as a factory for creatuing TutorialClientListeners.
    * @param session The ClientSession provided by the PDS API.
    * @return The ClientSessionListener to associate with the ClientSession.
    */
    static public TutorialClientListener loggedIn(ClientSession session, LastMessageMap map) 
    {
        TutorialClientListener me = new TutorialClientListener();
        me.setSession(session, map);
        
        return me;
    }
    
    /**
     * An internal method for congifuring a TutorialClientListener.
     * @param session The ClientSession provided by the PDS API.
     */
    private void setSession(ClientSession session, LastMessageMap map)
    {
        AppContext.getDataManager().markForUpdate(this);
        this.session = AppContext.getDataManager().createReference(session);
        this.lastMessageMap = AppContext.getDataManager().createReference(map);    
    }

     /**
     * This is called by the PDS API whenever the user disconnects.
     * @param graceful Whether or not the disconnect was graceful.
     */
    public void disconnected(boolean graceful) {
        String s = "User logged out ";
        if(!graceful)
        {
            s = s + "un";
        }
        s = s + "gracefully.";
        System.out.println(s);
    }
    
   /**
    * This is called by the PDS API whenever a message is recieved from the
    * client.
    * @param messageget The recieved message.
    */
    public void receivedMessage(ByteBuffer messageget) {
        try
        {
            OpCode code = getOpCode(messageget);
            if(code == null)
                return;
            parsePacket(code, messageget);
        }
        catch (Exception e)
        {
           System.out.println("");
        }
    }

    /**
     * This strips the OpCode out of the message, leaving only the payload.
     * @param message The ByteBuffer provided by the API.
     * @return The OpCode of the message.
     */
    public OpCode getOpCode(ByteBuffer message)
    {
        byte opcode = message.get();
        if(opcode < 0 || opcode >= OpCode.values().length)
        {
            System.out.println("Bad packet: " + opcode);
            return null;
        }
        return OpCode.values()[opcode];
    }
    
    /**
     * This parses the packet based on the given opcode.
     * @param message The ByteBuffer provided by the API, minus the OpCode.
     * @return The OpCode of the message.
     */
    public void parsePacket(OpCode code, ByteBuffer message)
    {
        ByteBuffer newBytes;
        switch(code)
        {
            case MESSAGE:
                 byte[] bytes = new byte[message.remaining()];
                message.get(bytes);
                String messagetext = new String(bytes);
                lastMessageMap.get().map.put(session.get().getName(), messagetext);
                System.out.println("Got message from client " + session.get().getName() + ": " + messagetext);
                messagetext = session.get().getName() + ">" + messagetext;
                newBytes = ByteBuffer.wrap(messagetext.getBytes());
                session.get().send(newBytes);
                break;
            case LASTMESSAGE:
                String s = lastMessageMap.get().map.get(session.get().getName());
                if(s == null)
                    s = "Server> No previous message.";
                else
                    s = "Server> Last Message: " + s;
                newBytes = ByteBuffer.wrap(s.getBytes());
                session.get().send(newBytes);
                break;
            default:
                System.out.println("Got unrecognized packet.");
                break;
        }
    }
    
}
