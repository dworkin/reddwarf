To run the Project Snowman server, open up a terminal or command prompt.
Navigate to the Server directory.

cd Server

and run the following command:

java -jar cmdlauncher.jar

This jar file uses the command.properties file and runs Project Darkstar
with the proper native libraries while using the Project Snowman server
application.

To run the Project Snowman client, open up a terminal or command prompt.
Navigate to the Client directory.

cd Client

and run the following command:

java -jar cmdlauncher.jar

This runs the client, which will connect to the server.

Enjoy :)