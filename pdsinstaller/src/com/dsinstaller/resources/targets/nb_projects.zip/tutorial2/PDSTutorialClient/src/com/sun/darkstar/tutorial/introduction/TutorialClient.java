

package com.sun.darkstar.tutorial.introduction;

import com.sun.sgs.client.simple.SimpleClient;
import com.sun.sgs.client.ClientChannel;
import com.sun.sgs.client.ClientChannelListener;
import com.sun.sgs.client.simple.SimpleClientListener;


import java.io.IOException;
import java.net.PasswordAuthentication;
import java.nio.ByteBuffer;
import java.util.Properties;

/**
 * This is the back end for the tutorial.  It is the class that handles all
 * incoming messages fromthe Project Darkstar API.
 * 
 * @author Chris Scalabrini
 */
public class TutorialClient implements SimpleClientListener{

    private SimpleClient session;
    private ITutorialWorld world;
    
    /**
     * When the connection to the server is to be gracefully terminated, call
     * this.
     */
    public void disconnect()
    {
        //Note, client boolean is whether or not it is UNGRACEFUL and the
        //server is whether or not it is GRACEFUL.
        session.logout(false);
    }
    
    /**
     * 
     * @param p The Log-in properties.  Note that necessary properties include
     * "host" and "port", and all others will be ignored.
     * @return Returns the tutorial world to use.
     * @throws java.lang.Exception When the log-in fails, this will get thrown.
     */
    public ITutorialWorld logIn(Properties p) throws Exception
    {
        try
        {
            session.login(p);
            world = new TutorialWorld();
            return world;
        }
        catch (Exception e)
        {
            throw new Exception("Log-in failed.");
        }
    }
    
    /**
     * When the front-end needs to send a string to the server, this method is
     * used.
     * @param b The string to be sent.
     */
    public void sendMessage(String b)
    {
        try
        {
            byte[] bytes = new byte[b.length() + 1];
            ByteBuffer buffer = ByteBuffer.wrap(bytes);
            int code = OpCode.MESSAGE.ordinal();
            buffer.put((byte)code);
            buffer.put(b.getBytes());
            buffer.flip();
            session.send(buffer);
        }
        catch (IOException e)
        {
        }
    }
    
     /**
     * When the front-end needs to request the previous string, this method is
     * used.
     * @return If it works, true.  False otherwise.
     */
    public void requestLastMessage()
    {
        try
        {
            byte[] bytes = new byte[1];
            ByteBuffer buffer = ByteBuffer.wrap(bytes);
            buffer.put((byte)OpCode.LASTMESSAGE.ordinal());
            buffer.flip();
            session.send(buffer);
        }
        catch(IOException e)
        {
        }   
    }
    
    public TutorialClient()
    {
        session = new SimpleClient(this);
    }
    
    /**
     * Generates a random username and a blank password.
     * @return The PasswordAuthentication to be used for the session.
     */
    public PasswordAuthentication getPasswordAuthentication() { 
        return new PasswordAuthentication("tutorialClient-" + 
                (new java.util.Random().nextInt(1000)), "guest".toCharArray());
    }

    /**
     * This is called by the Project Darkstar API.  No need to ever call it.
     */
    public void loggedIn() {
        System.out.println("Logged in successfully.  Starting");
        world.activate();
    }

    /**
     * This is called by the Project Darkstar API.  No need to ever call it.
     * @param arg0 The reason for the failure.
     */
    public void loginFailed(String arg0) {
        System.out.println("Failed to log in.");
        world.bail();
    }

    /**
     * This is called by the Project Darkstar API.  No need to ever call it.
     * @param arg0 Whether or not the disconnect was graceful..
     * @param arg1 The reason for the disconnect.
     */
    public void disconnected(boolean arg0, String arg1) {
        System.out.println("Disconnected: " + arg1);
        world.bail();
    }

    
    /**
     * This is called by the Project Darkstar API.  No need to ever call it.
     * @param arg0 The ClientChannel to use.
     */
    public ClientChannelListener joinedChannel(ClientChannel arg0) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
    /**
     * This is called by the Project Darkstar API.  No need to ever call it.
     * @param arg0 The ByteBuffer containing the recieved message.
     */
    public void receivedMessage(ByteBuffer arg0) {
        byte[] bytes = new byte[arg0.remaining()];
        arg0.get(bytes);
        String s = new String(bytes);
        System.out.println("##" + s);
        System.out.println("");
    }

    /**
     * This is called by the Project Darkstar API.  No need to ever call it.
     * It gets called when you have successfully reconnected.
     */
    public void reconnected() {
        System.out.println("Reconnected!");
    }

    /**
     * This is called by the Project Darkstar API.  No need to ever call it.
     * This gets called when a reconnect is being attempted.
     */
    public void reconnecting() {
        System.out.println("Reconnecting...");
    }

}
