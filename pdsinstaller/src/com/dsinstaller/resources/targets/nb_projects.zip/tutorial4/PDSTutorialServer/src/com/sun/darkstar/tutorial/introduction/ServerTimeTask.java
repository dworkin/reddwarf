

package com.sun.darkstar.tutorial.introduction;

import com.sun.sgs.app.AppContext;
import com.sun.sgs.app.Channel;
import com.sun.sgs.app.ManagedObject;
import com.sun.sgs.app.ManagedReference;
import com.sun.sgs.app.Task;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This task, given a channel, spams the clients with the current server time.
 * @author Chris Scalabrini
 */
public class ServerTimeTask implements Task, ManagedObject, Serializable {

    ManagedReference<Channel> chatChannel;
    
    /**
     * 
     * @param channel The channel to spam to.
     */
    public ServerTimeTask(Channel channel)
    {
        chatChannel = AppContext.getDataManager().createReference(channel);
    }
    
    /**
     * Sends all clients on the channel a message containing the current time.
     * @throws java.lang.Exception
     */
    public void run() throws Exception {
        chatChannel.get().send(null, ByteBuffer.wrap(("Server Time: " + getDateTime()).getBytes()));
    }
    
    /**
     * Gets the current time as a string.
     * @return The time, in string format.
     */
    private String getDateTime() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        return dateFormat.format(date);
    }

}
