
package com.sun.darkstar.tutorial.introduction;

import com.sun.sgs.app.AppContext;
import com.sun.sgs.app.AppListener;
import com.sun.sgs.app.Channel;
import com.sun.sgs.app.ClientSession;
import com.sun.sgs.app.ClientSessionListener;
import com.sun.sgs.app.Delivery;
import com.sun.sgs.app.ManagedReference;
import java.io.Serializable;
import java.util.Properties;

/**
 * This is the starting point for any Project Darkstar application.
 * @author Chris Scalabrini
 */
public class TutorialServer implements AppListener, Serializable{
    
    ManagedReference<LastMessageMap> msgMap;
    ManagedReference<Channel> channel;

    /**
     * This is only ever called the first time its run.  Beyond that, its
     * called when the DSDB is wiped clean.
     * @param prop The initial properties.
     */
    public void initialize(Properties prop) {
        System.out.println("Initializing tutorial server.");
        msgMap = AppContext.getDataManager().createReference(new LastMessageMap());
        channel = AppContext.getDataManager().createReference
                (AppContext.getChannelManager().createChannel("ChatRoom", null, Delivery.RELIABLE));
        
        AppContext.getTaskManager().schedulePeriodicTask(new ServerTimeTask(channel.get()), 0, 6000);
    }
    
    /**
     * Whenever a user logs in, this is called.
     * @param session The session for the client.
     * @return The listener for a client.
     */
    public ClientSessionListener loggedIn(ClientSession session) {
        return TutorialClientListener.loggedIn(session, msgMap.get(), channel.get());
    }

}
