

package com.sun.darkstar.tutorial.introduction;

import com.sun.sgs.app.AppContext;
import com.sun.sgs.app.Channel;
import com.sun.sgs.app.ClientSessionListener;
import com.sun.sgs.app.ClientSession;
import com.sun.sgs.app.ManagedObject;
import com.sun.sgs.app.ManagedReference;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.Iterator;

/**
 * This is the TutorialClientListener for the Quick-Start tutorials.
 * @author Chris Scalabrini
 */
public class TutorialClientListener implements ClientSessionListener, ManagedObject, Serializable {


    ManagedReference<ClientSession> session = null;
    ManagedReference<LastMessageMap> lastMessageMap; 
    ManagedReference<Channel> chatChannel;

    /**
     * We don't do any form of filtering, so we don't do anything. Simple.
     * @param arg0 The channel
     * @param arg1 The client
     * @param arg2 The message
     */
    public void receivedMessage(Channel arg0, ClientSession arg1, ByteBuffer arg2) {
        
    }
    
   /**
    * This method acts as a factory for creatuing TutorialClientListeners.
    * @param session The ClientSession provided by the PDS API.
    * @return The ClientSessionListener to associate with the ClientSession.
    */
    static public TutorialClientListener loggedIn(ClientSession session, LastMessageMap map, Channel channel) 
    {
        TutorialClientListener me = new TutorialClientListener();
        me.setSession(session, map, channel);
        
        return me;
    }
    
    /**
     * An internal method for congifuring a TutorialClientListener.
     * @param session The ClientSession provided by the PDS API.
     * @param map The last message map.
     * @param channel The channel for all users to use.
     */
    private void setSession(ClientSession session, LastMessageMap map, Channel channel)
    {
        AppContext.getDataManager().markForUpdate(this);
        this.session = AppContext.getDataManager().createReference(session);
        this.lastMessageMap = AppContext.getDataManager().createReference(map);
        this.chatChannel = AppContext.getDataManager().createReference(channel);
        
        chatChannel.get().join(this.session.get());
        int i = 0;
        Iterator<ClientSession> it = chatChannel.get().getSessions();
        while(it.hasNext())
        {
            it.next();
            i++;
        }
        System.out.println("Number of clients in chat room: " + i);
    }

     /**
     * This is called by the PDS API whenever the user disconnects.
     * @param graceful Whether or not the disconnect was graceful.
     */
    public void disconnected(boolean graceful) {
        chatChannel.get().send(null, ByteBuffer.wrap((session.get().getName() + " left out.").getBytes()));
        String s = "User logged out ";
        if(!graceful)
        {
            s = s + "un";
        }
        s = s + "gracefully.";
        System.out.println(s);
    }

   /**
    * This is called by the PDS API whenever a message is recieved from the
    * client.
    * @param messageget The recieved message.
    */
    public void receivedMessage(ByteBuffer messageget) {
        try
        {
            OpCode code = getOpCode(messageget);
            if(code == null)
                return;
            parsePacket(code, messageget);
        }
        catch (Exception e)
        {
           System.out.println("");
        }
    }
    
    /**
     * This strips the OpCode out of the message, leaving only the payload.
     * @param message The ByteBuffer provided by the API.
     * @return The OpCode of the message.
     */    
    public OpCode getOpCode(ByteBuffer message)
    {
        byte opcode = message.get();
        if(opcode < 0 || opcode >= OpCode.values().length)
        {
            System.out.println("Bad packet: " + opcode);
            return null;
        }
        return OpCode.values()[opcode];
    }
    
    /**
     * This parses the packet based on the given opcode.
     * @param message The ByteBuffer provided by the API, minus the OpCode.
     * @return The OpCode of the message.
     */
    public void parsePacket(OpCode code, ByteBuffer message)
    {
        ByteBuffer newBytes;
        switch(code)
        {
            case MESSAGE:
                 byte[] bytes = new byte[message.remaining()];
                message.get(bytes);
                String messagetext = new String(bytes);
                lastMessageMap.get().map.put(session.get().getName(), messagetext);
                System.out.println("Got message from client " + session.get().getName() + ": " + messagetext);
                messagetext = session.get().getName() + ">" + messagetext;
                newBytes = ByteBuffer.wrap(messagetext.getBytes());
                chatChannel.get().send(null, newBytes);
                break;
            case LASTMESSAGE:
                String s = lastMessageMap.get().map.get(session.get().getName());
                if(s == null)
                    s = "Server> No previous message.";
                else
                    s = "Server> Last Message: " + s;
                newBytes = ByteBuffer.wrap(s.getBytes());
                session.get().send(newBytes);
                break;
            default:
                System.out.println("Got unrecognized packet.");
                break;
        }
    }
    
}
