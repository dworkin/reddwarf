


package com.sun.darkstar.tutorial.introduction;

import java.util.Properties;

/**
 * Simply the main method wrapper class.  It constructs the Properties needed
 * by the Client API, and initializes the client.
 * 
 * @author Chris Scalabrini
 */
public class TutorialDriver {
    
    static private TutorialClient client;
    
    public static void main(String[] args)
    {
        Properties connectionProps = new Properties();
        connectionProps.put("port", "1139");
        connectionProps.put("host", "localhost");
        client = new TutorialClient();
        try       
        {
            client.logIn(connectionProps).run(client);
        }
        catch (Exception e)
        {
            System.out.println("Error logging in.  Terminating client.");
            return;
        } 
    }
}