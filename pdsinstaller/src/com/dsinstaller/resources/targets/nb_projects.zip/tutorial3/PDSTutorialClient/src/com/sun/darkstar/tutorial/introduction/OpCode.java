/**
 * Sun-related mumbo jumbo
 */

package com.sun.darkstar.tutorial.introduction;

/**
 * This is the chat program set of opcodes.
 * @author Chris Scalabrini
 */
public enum OpCode {
    NULL, MESSAGE, LASTMESSAGE
}
