

package com.sun.darkstar.tutorial.introduction;

/**
 * This interface covers all necessary functionality from the perspective of the
 * Project Darkstar tutorial client back-end.
 * 
 * @author Chris Scalabrini
 */
public interface ITutorialWorld {
    
    /**
     * This method is required to keep the main thread busy until the program
     * needs to exit!  Should the main thread exit, then the program will
     * terminate, thus serving no purpose.
     * 
     * @param client The TutorialClient that implements SimpleClient.
     */
    public void run(TutorialClient client);
    
    /**
     * This method informs the ITutorialWorld that the client has established
     * a connection with the server.
     */
    public void activate();
    
    /**
     * This method informs the ITutorialWorld that the connection to the server
     * has been lost, and the client should bail out.
     */
    public void bail();
}
