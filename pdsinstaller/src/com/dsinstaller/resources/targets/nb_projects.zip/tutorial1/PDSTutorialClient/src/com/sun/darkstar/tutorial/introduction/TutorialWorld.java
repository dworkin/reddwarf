
package com.sun.darkstar.tutorial.introduction;

import java.util.Scanner;

/**
 * This class is an example "hacked together" front-end for our TutorialClient.
 * It can be very easily replaced with a Swing front-end, as long as it
 * implements ITutorialWorld.
 * 
 * @author Chris Scalabrini
 */
public class TutorialWorld implements ITutorialWorld{

    boolean keepRunning = true;
    boolean activated = false;
    
    
    /**
     * The constructor doesn't need to do anything. 
     */
    public TutorialWorld()
    {}
    
    /**
     * Project Darkstar's client needs to have the main thread continue running
     * while the worker threads in the background communicate with the server.
     * A while loop that continues to run is typical as far as game loops are
     * concerned.
     * 
     * @param client The TutorialClient that implements the SimpleClient
     * interface.
     */
    public void run(TutorialClient client)
    {
        Scanner scanner = new Scanner(System.in);
        while(keepRunning)
        {
            if(activated)
            {
                String s = scanner.nextLine();
                if(s.startsWith("/quit"))
                {
                    break;
                }
                client.sendMessage(s);
            }
        }
        client.disconnect();
    }
    
    /**
     * This is called when the server is connected to the client.
     */
    public void activate()
    {
        activated = true;
    }
    
    /**
     * This is called when something goes wrong and the program needs to die.
     */
    public void bail()
    {
        keepRunning = false;
    }
}
