

package com.sun.darkstar.tutorial.introduction;

import com.sun.sgs.app.AppContext;
import com.sun.sgs.app.ClientSessionListener;
import com.sun.sgs.app.ClientSession;
import com.sun.sgs.app.ManagedObject;
import com.sun.sgs.app.ManagedReference;
import java.io.Serializable;
import java.nio.ByteBuffer;

/**
 * This is the TutorialClientListener for the Quick-Start tutorials.
 * @author Chris Scalabrini
 */
public class TutorialClientListener implements ClientSessionListener, 
        ManagedObject, Serializable {

    ManagedReference<ClientSession> session = null;
    
    /**
     * This method acts as a factory for creatuing TutorialClientListeners.
     * @param session The ClientSession provided by the PDS API.
     * @return The ClientSessionListener to associate with the ClientSession.
     */
    static public TutorialClientListener loggedIn(ClientSession session) 
    {
        TutorialClientListener me = new TutorialClientListener();
        me.setSession(session);
        System.out.println("User logged in.");
        return me;
    }
    
     /**
     * An internal method for congifuring a TutorialClientListener.
     * @param session The ClientSession provided by the PDS API.
     */
    private void setSession(ClientSession session)
    {
        AppContext.getDataManager().markForUpdate(this);
        this.session = AppContext.getDataManager().createReference(session);
    }

    /**
     * This is called by the PDS API whenever the user disconnects.
     * @param graceful Whether or not the disconnect was graceful.
     */
    public void disconnected(boolean graceful) {
        String s = "User logged out ";
        if(!graceful)
        {
            s = s + "un";
        }
        s = s + "gracefully.";
        System.out.println(s);
    }

   /**
    * This is called by the PDS API whenever a message is recieved from the
    * client.
    * @param messageget The recieved message.
    */
    public void receivedMessage(ByteBuffer messageget) {
        try
        {
            byte[] bytes = new byte[messageget.remaining()];
            messageget.get(bytes);
            String message = new String(bytes);
            System.out.println("Got message from client " + session.get().getName() + ": " + message);
            ByteBuffer b = ByteBuffer.wrap(bytes);
            session.get().send(b);
        }
        catch (Exception e)
        {}
    }
    
}
