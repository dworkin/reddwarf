-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
drop view sysroot.dual cascade;
drop view sysroot.tbtprivileges cascade;
drop view sysroot.schemaprivileges cascade;
drop view sysroot.tableprivileges cascade;
drop view sysroot.allusers cascade;
drop view sysroot.alltbts cascade;
drop view sysroot.mytbts cascade;
drop view sysroot.allindexcols cascade;
drop view sysroot.allindexes cascade;
drop view sysroot.allcolumns cascade;
drop view sysroot.allviewtexts cascade;
drop view sysroot.schemaviews cascade;
drop view sysroot.allviews cascade;
drop view sysroot.myviews cascade;
drop view sysroot.tablereplicas cascade;
drop view sysroot.tablefragments cascade;
drop view sysroot.schematables cascade;
drop view sysroot.alltables cascade;
drop view sysroot.mytables cascade;
drop view sysroot.allschemas cascade;
drop view sysroot.myschemas cascade;
drop view sysroot.usrtbl cascade;
drop view sysroot.statistics cascade;
