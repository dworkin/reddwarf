-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
-- File:    ddviews-create.sql
-- Author:  Tor Molnes 17-jul-2000
-- Purpose: Create Dictionary views
--
--
-- STATISTICS
--
create view sysroot.statistics(
  tableid, rowcount, datablocks)
as
select
  tableid, 0, 0
from
  sysroot.systbl;
--
--
-- USRTBL
--
create view sysroot.usrtbl(
  tableid, tablename, ascendantid, tabletypeid,
  ownerid, entitytype, created, modified, organization, additional)
as
select
  tableid, tablename, ascendantid, tabletypeid,
  ownerid, entitytype, created, modified, organization, additional
from
  sysroot.systbl as t
where
  exists (select * from sysroot.sysacc as c
          where c.resourcetype=1 and c.resourceid=t.tableid and
               (c.grantee=100 or c.grantee=current_userid))
  or
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128);
--
--
-- MYSCHEMAS
--
create view sysroot.myschemas(
  schemaid, schemaname, ownername,
  ownerid, created, modified, additional)
as
select
  t.tableid, t.tablename, cast(current_user as char(32)),
  t.ownerid, t.created, t.modified, t.additional
from
  sysroot.systbl as t
where
  t.entitytype=2 and
  t.ownerid=current_userid and
  t.ascendantid=0;
--
--
-- ALLSCHEMAS
--
create view sysroot.allschemas(
  schemaid, schemaname, ownername,
  ownerid, created, modified, additional)
as
select
  t.tableid, t.tablename, u.username,
  t.ownerid, t.created, t.modified, t.additional
from
  sysroot.systbl as t join
  sysroot.sysusr as u on t.ownerid=u.userid
where
  t.entitytype=2 and
  t.ascendantid=0;
--
--
-- MYTABLES
--
create view sysroot.mytables(
  schemaid, tableid, schemaname, tablename, tabletypename, ownername,
  tabletypeid, ownerid, created, modified, organization, additional)
as
select
  d.tableid, t.tableid, d.tablename, t.tablename, b.tabletypename,
  cast(current_user as char(32)),
  b.tabletypeid, t.ownerid, t.created, t.modified, t.organization, t.additional
from
  (sysroot.systbl as d
   join
   sysroot.systbl as t on d.tableid=t.ascendantid) 
   join
   sysroot.systbt as b on t.tabletypeid=b.tabletypeid
where
  t.entitytype=1 and
  t.ownerid=current_userid;
--
--
-- ALLTABLES
--
create view sysroot.alltables(
  schemaid, tableid, schemaname, tablename, tabletypename, ownername,
  tabletypeid, ownerid, created, modified, organization, additional)
as
select
  d.tableid, t.tableid, d.tablename, t.tablename, b.tabletypename, u.username,
  b.tabletypeid, t.ownerid, t.created, t.modified, t.organization, t.additional
from
 ((sysroot.systbl as d
   join
   sysroot.usrtbl as t on d.tableid=t.ascendantid)
   join
   sysroot.systbt as b on t.tabletypeid=b.tabletypeid)
   join
   sysroot.sysusr as u on t.ownerid=u.userid
where
  t.entitytype=1;
--
--
-- SCHEMATABLES
--
create view sysroot.schematables(
  schemaid, tableid, schemaname, tablename, tabletypename, ownername,
  tabletypeid, ownerid, created, modified, organization, additional)
as
select
  current_schemaid, t.tableid, cast(current_schema as char(32)),
  t.tablename, b.tabletypename, u.username,
  tabletypeid, t.ownerid, t.created, t.modified, t.organization, t.additional
from
  (sysroot.usrtbl as t join
   sysroot.systbt as b using(tabletypeid)) join
   sysroot.sysusr as u on t.ownerid=u.userid
where
  t.entitytype=1 and
  t.ascendantid=current_schemaid;
--
--
-- TABLEREPLICAS
--
create view sysroot.tablereplicas(
schemaid, tableid, schemaname, tablename, replseq, versionid, dictvers,
nodeid,   fragseq, fversionid, ordposition, storedid)
as
select t.schemaid,t.tableid,t.schemaname,t.tablename,
       k.replseq,k.versionid,k.dictvers,k.nodeid,k.fragseq,k.fversionid,
       k.ordposition,k.storedid
from sysroot.krnreplicas as k
     join
     sysroot.alltables as t on k.tableid=t.tableid
where versionid>=(select max(versionid)
                 from krnreplicas as kg
                 where k.tableid=kg.tableid)
and versionid = (select max(versionid)
                 from krnreplicas as kg
                 where k.tableid=kg.tableid and k.replseq=kg.replseq);
--
--
-- TABLEFRAGMENTS
--
create view sysroot.tablefragments(
schemaid, tableid, schemaname, tablename, fragseq, versionid, dictvers,
ordposition, pfragseq, pversionid)
as
select t.schemaid,t.tableid,t.schemaname,t.tablename,
       f.fragseq,f.versionid,f.dictvers,f.ordposition,f.pfragseq,f.pversionid
from sysroot.krnfragments as f
     join
     sysroot.alltables as t on f.tableid=t.tableid
where versionid=(select max(versionid)
                 from krnfragments as fg
                 where f.tableid=fg.tableid);
--
--
-- MYVIEWS
--
create view sysroot.myviews(
  schemaid, viewid, schemaname, viewname, ownername, ownerid,
  created, modified, additional)
as
select
  d.tableid, t.tableid, d.tablename, t.tablename,
  cast(current_user as char(32)), t.ownerid,
  t.created, t.modified, t.additional
from
  sysroot.systbl as d
  join
  sysroot.systbl as t on d.tableid=t.ascendantid
where
  t.entitytype=10 and
  t.ownerid=current_userid;
--
--
-- ALLVIEWS
--
create view sysroot.allviews(
  schemaid, viewid, schemaname, viewname, ownername, ownerid,
  created, modified, additional)
as
select
  d.tableid, t.tableid, d.tablename, t.tablename, u.username, t.ownerid,
  t.created, t.modified, t.additional
from
 (sysroot.systbl as d
  join
  sysroot.usrtbl as t on d.tableid=t.ascendantid)
  join
  sysroot.sysusr as u on t.ownerid=u.userid
where
  t.entitytype=10;
--
--
-- SCHEMAVIEWS
--
create view sysroot.schemaviews(
  schemaid, viewid, schemaname, viewname, ownername, ownerid,
  created, modified, additional)
as
select
  d.tableid, t.tableid, d.tablename, t.tablename, u.username, t.ownerid,
  t.created, t.modified, t.additional
from
 (sysroot.systbl as d
  join
  sysroot.usrtbl as t on d.tableid=t.ascendantid)
  join
  sysroot.sysusr as u on t.ownerid=u.userid
where
  t.entitytype=10 and
  t.ascendantid=current_schemaid;
--
--
-- ALLVIEWTEXTS
--
create view sysroot.allviewtexts(
  viewid, viewname, textlineno, textlines)
as
select
  tableid, t.tablename, d.seqno, d.definition
from
  sysroot.systbl as t join
  sysroot.systbldef as d using(tableid)
where
  t.entitytype=10 and
  tableid in(select tableid from sysroot.usrtbl);
--
--
-- ALLCOLUMNS
--
create view sysroot.allcolumns(
  tableid, tablename, columnid, columnname,
  datatype, offset, specification, additional, addinfo)
as
select
  t.tableid, t.tablename, a.seqno, a.attrname,
  a.maintype, a.offset, a.specification,
  a.additional, a.addinfo
from
  sysroot.usrtbl as t join
  sysroot.systbtatt as a using(tabletypeid)
where
  t.entitytype in (1,10);
--
--
-- ALLINDEXES
--
create view sysroot.allindexes(
  tableid, indexid, tablename, indexname,
  created, modified, organization, additional)
as
select
  t.tableid, i.tableid, t.tablename, i.tablename,
  i.created, i.modified, i.organization, i.additional
from
  sysroot.systbl as i join
  sysroot.usrtbl as t on i.ascendantid=t.tableid
where
  t.entitytype=1;
--
--
-- ALLINDEXCOLS
--
create view sysroot.allindexcols(
  tableid, indexid, tablename, indexname,
  columnid, columnname, non_unique, collate_seq)
as   
select
  t.tableid, i.tableid, t.tablename, i.tablename, d.seqno,
  cast(substring(d.definition FROM 1 FOR 32) as char(32)),
  (i.organization/16) % 2 as non_unique,
  cast(substring(d.definition FROM 34 for 4) as char(4))
from
  (sysroot.usrtbl as t join
   sysroot.systbl as i on i.ascendantid=t.tableid) join
   sysroot.systbldef as d on i.tableid=d.tableid
where  t.entitytype=1;
--
--
-- MYTBTS
--
create view sysroot.mytbts(
  tabletypeid, tabletypename, ownername, ownerid,
  tablecount, created, modified)
as
select
  b.tabletypeid, b.tabletypename, cast(current_user as char(32)),
  b.ownerid, b.tablecount, b.created, b.modified
from
  sysroot.systbt as b
where
  b.ownerid=current_userid;
--
--
-- ALLTBTS
--
create view sysroot.alltbts(
  tabletypeid, tabletypename, ownername, ownerid,
  tablecount, created, modified)
as
select
  b.tabletypeid, b.tabletypename, u.username, b.ownerid,
  b.tablecount, b.created, b.modified
from
  sysroot.systbt as b join
  sysroot.sysusr as u on b.ownerid=u.userid
where
  exists (select * from sysroot.sysacc as c
          where c.resourcetype=2 and c.resourceid=b.tabletypeid and
               (c.grantee=100 or c.grantee=current_userid))
  or
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128);
--
--
-- ALLUSERS
--
create view sysroot.allusers(
  userid, username, privilege, grouporuser,
  defaultpath, description)
as
select
  u.userid, u.username, u.privilege, u.grouporuser,
  u.defaultpath, u.description
from
  sysroot.sysusr as u;
--
--
-- TABLEPRIVILEGES
--
create view sysroot.tableprivileges(
  tableid, tablename,
  grantorid, grantorname, granteeid, granteename, 
   privmask, grantmask)
as
select
  t.tableid, t.tablename,
  a.grantor, grantor.username, a.grantee, grantee.username,
  a.privilege % 65536, a.privilege / 65536
from
  sysroot.sysacc as a join
  sysroot.sysusr as grantor on grantor.userid = a.grantor join
  sysroot.sysusr as grantee on grantee.userid = a.grantee join
  sysroot.systbl as t on t.tableid=a.resourceid
where
  a.resourcetype = 1     and
  t.entitytype in (1,10) and
 (a.grantee = 100            or
  a.grantee = current_userid or
  a.grantor = current_userid or
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128))
union all
select
  t.tableid, t.tablename,
  1 as grantorid, 'system' as grantorname,
  1 as granteeid, 'system' as granteename,
  31 as privmask, 31 as grantmask
from
  sysroot.systbl as t
where
  t.entitytype in (1,10) and
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128);
--
--
-- SCHEMAPRIVILEGES
--
create view sysroot.schemaprivileges(
  schemaid, schemaname,
  grantorid, grantorname, granteeid, granteename,
  privmask, grantmask)
as
select
  t.tableid, t.tablename,
  a.grantor, grantor.username, a.grantee, grantee.username,
  a.privilege % 65536, a.privilege / 65536
from
  sysroot.sysacc as a join
  sysroot.sysusr as grantor on grantor.userid = a.grantor join
  sysroot.sysusr as grantee on grantee.userid = a.grantee
  join sysroot.systbl as t on t.tableid=a.resourceid
where
  t.entitytype=2   and
  t.ascendantid=0  and
  a.resourcetype=1 and
 (a.grantee = 100            or
  a.grantee = current_userid or
  a.grantor = current_userid or
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128))
union all
select
  t.tableid, t.tablename,
  1 as grantorid, 'system' as grantorname,
  1 as granteeid, 'system' as granteename,
  64 as privmask, 64 as grantmask
from
  sysroot.systbl as t
where
  t.entitytype=2  and
  t.ascendantid=0 and
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128);
--
--
-- TBTPRIVILEGES
--
create view sysroot.tbtprivileges(
  tabletypeid, tabletypename,
  grantorid, grantorname, granteeid, granteename,
  privmask, grantmask)
as
select
  t.tabletypeid, t.tabletypename,
  a.grantor, grantor.username, a.grantee, grantee.username,
  a.privilege % 65536, a.privilege / 65536
from
  sysroot.sysacc as a join
  sysroot.sysusr as grantor on grantor.userid = a.grantor join
  sysroot.sysusr as grantee on grantee.userid = a.grantee join
  sysroot.systbt as t on t.tabletypeid=a.resourceid
where
  t.tabletypename <> '' and
  a.resourcetype = 2    and
 (a.grantee = 100            or
  a.grantee = current_userid or
  a.grantor = current_userid or
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128))
union all
select
  t.tabletypeid, t.tabletypename,
  1 as grantorid, 'system' as grantorname,
  1 as granteeid, 'system' as granteename,
   64 as privmask, 64 as grantmask
from
  sysroot.systbt as t
where
  t.tabletypename<>'' and
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128);
--
--
-- DUAL
--
create view sysroot.dual(
  empty_column)
as
select
  empty_column
from
  (values('')) as t(empty_column);
--
--
-- GRANT SELECT ON ALL DD VIEWS TO PUBLIC
--
grant select on sysroot.statistics to public;
grant select on sysroot.myschemas to public;
grant select on sysroot.allschemas to public;
grant select on sysroot.mytables to public;
grant select on sysroot.alltables to public;
grant select on sysroot.schematables to public;
grant select on sysroot.tablereplicas to public;
grant select on sysroot.tablefragments to public;
grant select on sysroot.myviews to public;
grant select on sysroot.allviews to public;
grant select on sysroot.schemaviews to public;
grant select on sysroot.allviewtexts to public;
grant select on sysroot.allcolumns to public;
grant select on sysroot.allindexes to public;
grant select on sysroot.allindexcols to public;
grant select on sysroot.mytbts to public;
grant select on sysroot.alltbts to public;
grant select on sysroot.allusers to public;
grant select on sysroot.tableprivileges to public;
grant select on sysroot.schemaprivileges to public;
grant select on sysroot.tbtprivileges to public;
grant select on sysroot.dual to public;
