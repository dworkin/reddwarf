-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
drop view odbc_25_41_1.odbc_tables cascade;
drop view odbc_25_41_1.odbc_columns cascade;
drop view odbc_25_41_1.odbc_columns_def cascade;
drop view odbc_25_41_1.odbc_primary cascade;
drop view odbc_25_41_1.odbc_special cascade;
drop view odbc_25_41_1.odbc_index cascade;
drop view odbc_25_41_1.odbc_stat cascade;
drop view odbc_25_41_1.odbc_col_priv cascade;
drop view odbc_25_41_1.odbc_tbl_priv cascade;
drop view odbc_25_41_1.odbc_tbl cascade;
