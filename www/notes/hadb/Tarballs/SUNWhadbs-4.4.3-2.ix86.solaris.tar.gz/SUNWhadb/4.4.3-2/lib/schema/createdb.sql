-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
-- File:   createdb.sql
-- Author: Roy Lyseng
-- Use:    List of SQL files to be processed during database boot procedure
--
krntables-create.sql
ddviews-create.sql
odbc_25_41_1-create.sql
jdbc_20_41_1-create.sql
jdbc_30_42_1-create.sql
