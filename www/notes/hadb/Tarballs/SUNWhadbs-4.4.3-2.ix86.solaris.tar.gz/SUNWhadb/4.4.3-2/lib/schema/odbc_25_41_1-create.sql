-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
-- File:    odbc_25_41_1-create.sql
-- Purpose: Create ODBC 2.5 Dictionary views,
--
-- Create schema for this set of views
--
create schema odbc_25_41_1;
set schema odbc_25_41_1;
--
--
-- ODBC_STATISTICS
-- Statistics information is not available in SQL
create view odbc_diststat(
  tableid, rowcount, datablocks)
as
select
  tableid, cast(NULL as integer), cast(NULL as integer)
from
  sysroot.systbl;
--
--
-- ODBC_TBL
--
create view odbc_tbl(
  tableid, tablename, ascendantid, 
  tabletypeid, nodegroupid, ownerid,
  entitytype, created, modified, organization, additional)
as
select
  tableid, tablename, ascendantid, tabletypeid, nodegroupid, ownerid,
  entitytype, created, modified, organization, additional
from
  sysroot.systbl as t
where
  exists (select * from sysroot.sysacc as c
          where  c.resourcetype=1 and c.resourceid=t.tableid and
                (c.grantee=100 or c.grantee=current_userid))
  or
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128);

--
--
-- ODBC_TABLES
--
create view odbc_tables(
  schemaname, tablename, tbltype, remarks, tableid)
as
select
  d.tablename, t.tablename,
  case t.entitytype
    when  1 then
      case when t.tableid < 1000 then 'SYSTEM TABLE'
                                 else 'TABLE'   end
    when 10 then 'VIEW'
    else         ''
  end,
  '', t.tableid
from
  sysroot.systbl as d join
  odbc_tbl as t on t.ascendantid=d.tableid
where
  t.entitytype in (1,10);
--
--
-- ODBC_COLUMNS
--
create view odbc_columns(
  schemaname, tablename, colname, seqno,
  datatype, offset, specification,
  nullable, varsize)
as                                         
select
  d.tablename, t.tablename, a.attrname, a.seqno,
  a.maintype, a.offset, a.specification,
  (a.additional%16) / 8, (a.additional%8192) / 4096
from
  odbc_tbl as t join
  sysroot.systbl as d on t.ascendantid=d.tableid join
  sysroot.systbtatt as a on t.tabletypeid=a.tabletypeid
where
  a.maintype <= 12
;

-- 
-- ODBC_COLUMNS_DEF
-- same as above, but with default value for each column
-- 
create view odbc_columns_def(
  schemaname, tablename, colname, seqno,
  datatype, offset, specification,
  nullable, varsize, column_def)
as                                         
select
  d.tablename, t.tablename, a.attrname, a.seqno,
  a.maintype, a.offset, a.specification,
  (a.additional%16) / 8, (a.additional%8192) / 4096,
  substring(x.definition from 8+position('default' in x.definition))
from
  odbc_tbl as t join
  sysroot.systbl as d on t.ascendantid=d.tableid join
  sysroot.systbtatt as a on t.tabletypeid=a.tabletypeid
  left outer join
  sysroot.systbtdef as x on a.tabletypeid = x.tabletypeid
                        and a.attrname =
  substring(x.definition from 1 for (position(' ' in x.definition)))
where
  a.maintype <= 12
;
--
--
-- ODBC_PRIMARY
--
create view odbc_primary(
  tableid, schemaname, tablename, colname, seqno,
  datatype, offset, specification,
  nullable, varsize)
as                                         
select
  t.tableid, d.tablename, t.tablename, a.attrname, a.addinfo + 1,
  a.maintype, a.offset, a.specification,
  (a.additional%16) / 8, (a.additional%8192) / 4096
from
  odbc_tbl as t join
  sysroot.systbl as d on t.ascendantid=d.tableid join
  sysroot.systbtatt as a on t.tabletypeid=a.tabletypeid
where
  t.entitytype=1         and
  a.additional%2=1       and
  a.additional%256 < 128 and
  a.maintype <= 12
;
--
--
-- ODBC_SPECIAL
-- 'best_rowid'  primary key columns
-- 'rowver'      lsn# and checksum#

create view odbc_special(
  schemaname, tablename, colname, seqno,
  datatype, offset, specification,
  nullable, varsize)
as                                         
select
  d.tablename, t.tablename, a.attrname,
  case a.maintype when 16 then a.seqno else a.addinfo + 1 end,
  a.maintype, a.offset, a.specification,
  (a.additional%16) / 8, (a.additional%8192) / 4096
from
  odbc_tbl as t join
  sysroot.systbl as d on t.ascendantid=d.tableid join
  sysroot.systbtatt as a on t.tabletypeid=a.tabletypeid
where
  (t.entitytype=1 and a.additional%2=1 and a.maintype <= 12) -- best_rowid
or(t.entitytype=1 and                      a.maintype  = 16) -- rowver
;

--
--
-- ODBC_INDEX
--
create view odbc_index(
  index_id, schemaname, tablename, index_name, 
  colname, seq_in_index, non_unique, collate_seq)
as   
select
  i.tableid, d.tablename, t.tablename, i.tablename,
  cast(substring(a.definition from 1 for 32) as char(32)),
  a.seqno + 1,
  (i.organization/16) % 2 as non_unique,
  cast(upper(substring(a.definition from 34 for 1)) as char(1))
from
  ((odbc_tbl as t join
    sysroot.systbl as d on t.ascendantid=d.tableid) join
   sysroot.systbl as i on i.ascendantid=t.tableid) join
  sysroot.systbldef as a on a.tableid=i.tableid
where  t.entitytype=1 -- table
   and d.entitytype=2 -- schema
   and i.entitytype=3 -- index
;
--
--
-- ODBC_STAT
--
create view odbc_stat(
  schemaname, tablename, cardinality, pages)
as
select
  d.tablename, t.tablename, s.rowcount, s.datablocks
from
  odbc_tbl as t join
  sysroot.systbl as d on t.ascendantid=d.tableid join
  odbc_diststat as s on t.tableid=s.tableid
where  t.entitytype=1 -- table
   and d.entitytype=2 -- schema
;
--
--
-- ODBC_TBL_PRIV
--
create view odbc_tbl_priv(
  schemaname, tablename, grantor, grantee,
  privilege, is_grantable, tabletypeid)
as
select
  d.tablename, t.tablename, 'system' as grantor, 'system' as grantee,
  priv.txt, 'YES' as is_grantable, t.tabletypeid
from
  sysroot.systbl as t join
  sysroot.systbl as d on t.ascendantid=d.tableid,
  (values ('SELECT'),('INSERT'),('UPDATE'),('DELETE'),('REFERENCES'))
  as priv(txt)
where
  t.entitytype in (1,10) and
  exists (select * from sysroot.sysusr
          where userid=current_userid and privilege=128)
union all
select
  d.tablename, t.tablename, grantor.username,grantee.username,
  priv.txt, grnt.txt as is_grantable, t.tabletypeid
from
  sysroot.sysacc as a join
  sysroot.sysusr as grantor on grantor.userid = a.grantor join
  sysroot.sysusr as grantee on grantee.userid = a.grantee join
  sysroot.systbl as t on t.tableid=a.resourceid join
  sysroot.systbl as d on t.ascendantid=d.tableid,
  (values (1,'SELECT'),(2,'INSERT'),(4,'UPDATE'),
          (8,'DELETE'),(16,'REFERENCES'))
          as priv(mask, txt),
  (values (0,'NO'), (1,'YES'))
          as grnt(mask,txt)
where
  (a.privilege/priv.mask) % 2 = 1 and
  (a.privilege/(priv.mask*65536)) % 2 = grnt.mask and
  (current_userid = a.grantor  or
   current_userid = a.grantee  or
   a.grantee = 100             or
   exists (select * from sysroot.sysusr
           where userid=current_userid and privilege=128))
;
--
--
-- ODBC_COL_PRIV
--
create view odbc_col_priv(
  schemaname, tablename, colname,
  grantor, grantee, privilege, is_grantable)
as
select
  t.schemaname, t.tablename, a.attrname,
  t.grantor, t.grantee, t.privilege, t.is_grantable
from
  odbc_tbl_priv as t
  join sysroot.systbtatt as a using(tabletypeid)
where
  a.maintype <= 12
;
--
-- GRANT TO PUBLIC
--
grant select on odbc_diststat to public;
grant select on odbc_tables to public;
grant select on odbc_columns to public;
grant select on odbc_columns_def to public;
grant select on odbc_special to public;
grant select on odbc_primary to public;
grant select on odbc_index to public;
grant select on odbc_stat to public;
grant select on odbc_tbl_priv to public;
grant select on odbc_col_priv to public;
