-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
-- File:    krntables-create.sql
-- Author:  Tor Molnes 29-aug-2000
-- Purpose: Declare system tables
--
--
-- Key  fields: tableid  Int32, replseq  Int16, nodeid   UInt16
-- Data fields: tplcount Int64, blkcount Int32, blkinuse Int32
--
--create table krnstatdict(
--  tableid    integer       not null,
--  replseq    smallint      not null,
--  nodeid     smallint      not null,
--  blkcount   integer       not null,
--  blkinuse   integer       not null,
--  primary key(tableid, replseq, nodeid)
--) existing 66;
--
-- 101<4 0<4
-- 2<1 1<1 2<2 10001<2 10002<2 16974416<4 65872<4 0<4 ''<0 0<1 0<1 0<1 0<1
create table krntables(
  tableid      integer       not null,
  versionid    integer       not null,
  dictvers     binary(1)     not null,
  partitioning binary(1)     not null,
  maxrepl      smallint      not null,
  fraghigh     smallint      not null,
  replhigh     smallint      not null,
  admcode1     integer       not null,
  admcode2     integer       not null,
  groupid      integer       not null,
  description  varchar(255),
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  dummy3       binary(1)     not null,
  dummy4       binary(1)     not null,
  primary key(tableid, versionid)
) existing 101;
--
-- 101<4 10001<2 0<4
-- 1<1 0<2 10001<2 0<4 0<2 0<4 0<1 0<1
create table krnfragments(
  tableid      integer       not null,
  fragseq      smallint      not null,
  versionid    integer       not null,
  dictvers     binary(1)     not null,
  ordposition  smallint      not null,
  pfragseq     smallint      not null,
  pversionid   integer       not null,
  lowrange     varbinary(1024) not null,
  highrange    varbinary(1024) not null,
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(tableid, fragseq, versionid)
) existing 102;
--
-- 304<4 10000<2 2<4
-- 1<1 0<2 10001<2 2<4 0<2 0<4 0<1 0<1
create table krnreplicas(
  tableid      integer       not null,
  replseq      smallint      not null,
  versionid    integer       not null,
  dictvers     binary(1)     not null,
  nodeid       smallint      not null,
  fragseq      smallint      not null,
  fversionid   integer       not null,
  ordposition  smallint      not null,
  storedid     integer       not null,
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(tableid, replseq, versionid)
) existing 103;
--
-- 1<4 0<4
-- 1<1 'code for endproc'<16 'dummy procecure'<15 0<1 0<1
create table krnprocedures(
  procedureid  integer       not null,
  versionid    integer       not null,
  dictvers     binary(1)     not null,
  compiledcode varbinary(2000) not null,
  sourcecode   varchar(2000),
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(procedureid, versionid)
) existing 104;
--
-- 0<4
-- 0<4 0<4 'node-0'<6 'active'<6 'no descr.'<9 0<1 0<1
create table krnnodes(
  nodeid       integer       not null,
  logicalid    integer       not null,
  dunitid      integer       not null,
  nodename     varchar(32)   not null,
  status       varchar(32)   not null,
  description  varchar(255),
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(nodeid)
) existing 105;
--
-- 0<4
-- 0<4 'dunit-0'<7 'no descr.'<9 0<1 0<1
create table krnredundancyunits(
  dunitid      integer       not null,
  siteid       integer       not null,
  dunitname    varchar(32)   not null,
  description  varchar(255),
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(dunitid)
) existing 106;
--
-- 0<4
-- 'site-0'<6 'no descr.'<9 0<1 0<1
create table krnsites(
  siteid       integer       not null,
  sitename     varchar(32)   not null,
  description  varchar(255),
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(siteid )
) existing 107;
--
-- 1000<4
-- 'sysnodes'<8 'system tables nodegroup spanning all nodes'<42 0<1 0<1
create table krnnodegroups(
  groupid      integer       not null,
  groupname    varchar(32)   not null,
  description  varchar(255),
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(groupid)
) existing 108;
--
-- 1000<4
-- -2147483647<4 0<1 0<1
create table krnnodegroupnodes(
  groupid      integer       not null,
  logicalnodes varbinary(2000) not null,
  dummy1       binary(1)     not null,
  dummy2       binary(1)     not null,
  primary key(groupid)
) existing 109;
--
-- GRANTS
