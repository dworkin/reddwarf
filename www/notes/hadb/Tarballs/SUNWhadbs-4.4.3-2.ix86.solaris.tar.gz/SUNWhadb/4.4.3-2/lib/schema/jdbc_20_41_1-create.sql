-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
-- DatabaseMetadata views for JDBC, written by Tor Didriksen.
-- 
-- These views are based on 
-- "JDBC API Tutorial and Reference, Second Edition"
-- by: White, Fisher, Cattell, Hamilton, Hapner
-- The DatabaseMetadata chapter is a bit vague on some points, so
-- I also had to consult "ODBC 3.5 Developer's Guide", by Roger E. Sanders.
-- 
-- Where the two books disagree, or the JDBC book is too vague, 
-- I have chosen to follow the ODBC spec.
-- 
-- 'column_size' occurs in getbestrowidentifier, getcolumns, 
--                         gettypeinfo, getversioncolumns
-- ODBC says: 
--           "The maximum number of bytes needed to display
--            the column data in character form"
-- I assume the inteded usage is to determine the size of a char buffer 
-- when converting values to/from char. Hence I return
--   - the number of decimal digits for numeric data types
--     (but omitting space for a possible +/- sign)
--   - some fixed size depending on type for date/time/interval
--   - length for char/varchar
--   - length*2 for binary/varbinary (assuming hex/nybble presentation)
-- 
-- Most of the views below are extensions to similar 
-- views in schema 'odbc_25_41_1'.
-- 
create schema jdbc_20_41_1;
set schema jdbc_20_41_1;



-- 
-- getbestrowidentifier / SQLSpecialColumns
-- The best row identifier is always the primary key
-- 'scope' will always be bestRowSession
-- 
create view getbestrowidentifier(
schemaname,            -- string: schema name   (input to getBestRowIdentifier)
tablename,             -- string: table name    (input to getBestRowIdentifier)
scope,                 -- short : 0,1,2         (input to getBestRowIdentifier)
nullable,              -- int   : 0/1           (input to getBestRowIdentifier)
seqno,                 -- short : column number (extra, so we can sort on it  )
column_name,           -- string: 
data_type,             -- short : java.sql.Types p.881
type_name,             -- string: type name used by the data source
column_size,           -- int   : precision
buffer_length,         -- int   : not used
decimal_digits,        -- short : scale
pseudo_column          -- short : 0,1,2
)
as
select
schemaname,            -- schemaname
tablename,             -- tablename
cast(2 as smallint),   -- scope == bestRowSession
t.nullable,            -- nullable
t.seqno,               -- seqno
t.colname,             -- column_name
cast(                  -- data_type
case t.datatype
when  1 then  5   -- smallint
when  2 then  4   -- integer
when  3 then -5   -- bigint
when  4 then  3   -- decimal
when  5 then  6   -- float
when  6 then  8   -- double
when  8 then  
  case t.varsize
  when  0 then  1 -- char
  else         12 -- varchar
  end
when  9 then 
  case t.varsize
  when  0 then -2 -- binary
  else         -3 -- varbinary
  end
when 11 then
  case (t.specification / 256) % 64 
  when 61 then 91 -- date
  when 34 then 92 -- time
  when 58 then 93 -- timestamp
  else 2222       -- ERROR
  end
else 1111         -- other
end
as smallint),
case                   -- type_name
when t.datatype =  1 then 'smallint                        ' 
when t.datatype =  2 then 'integer                         ' 
when t.datatype =  3 then 'double integer                  ' 
when t.datatype =  4 then 'decimal                         ' 
when t.datatype =  5 then 'real                            ' 
when t.datatype =  6 then 'double precision                ' 
when t.datatype =  8 and t.varsize = 0
                     then 'char                            ' 
when t.datatype =  8 and t.varsize = 1
                     then 'varchar                         ' 
when t.datatype =  9 and t.varsize = 0
                     then 'binary                          ' 
when t.datatype =  9 and t.varsize = 1
                     then 'varbinary                       ' 
when t.datatype = 11 and (t.specification / 256) % 64 = 61
                     then 'date                            ' 
when t.datatype = 11 and (t.specification / 256) % 64 = 34
                     then 'time                            ' 
when t.datatype = 11 and (t.specification / 256) % 64 = 58
                     then 'timestamp                       ' 
when t.datatype = 12 then 'interval                        '
else                      '                                ' 
end,
cast(                  -- column_size (when converted to char)
case         -- FIXME: check all sizes here
when t.datatype =  1 then  5                    -- smallint
when t.datatype =  2 then 10                    -- integer
when t.datatype =  3 then 19                    -- double integer
when t.datatype =  4 then 31                    -- decimal
when t.datatype =  5 then  7                    -- real
when t.datatype =  6 then 15                    -- double precision
when t.datatype =  8 then  t.specification      -- char/varchar
when t.datatype =  9 then  t.specification * 2  -- binary/varbinary
when t.datatype = 11 and (t.specification / 256) % 64 = 61
                     then 10                    -- date
when t.datatype = 11 and (t.specification / 256) % 64 = 34
                     then 8 + 6 + 1             -- time
when t.datatype = 11 and (t.specification / 256) % 64 = 58
                     then 19 + 6 + 1            -- timestamp
when t.datatype = 12 then 8                     -- interval
else null
end
as integer),
cast(0 as integer),    -- buffer_length, not used
cast(                  -- decimal_digits
case
when t.datatype =  4 then t.specification % 32  -- decimal
when t.datatype = 11 and (t.specification / 256) % 64 = 34
                     then t.specification % 32  -- time
when t.datatype = 11 and (t.specification / 256) % 64 = 58
                     then t.specification % 32  -- timestamp
when t.datatype = 12 then t.specification % 32  -- interval
else null
end
as smallint),
cast(1 as smallint)    -- pseudo_column (bestRowNotPseudo)
from odbc_25_41_1.odbc_primary  as t 
;



-- 
-- getcatalogs
-- Not supported, return empty set
-- 
create view getcatalogs(
table_cat              -- string: 
)
as
select cast(null as char) 
from sysroot.dual 
where 1=0
;



-- 
-- getcolumnprivileges / SQLColumnPrivileges
-- get description of access rights for the columns of a table
--  
create view getcolumnprivileges(
table_cat,             -- string: always NULL
table_schem,           -- string: 
table_name,            -- string: 
column_name,           -- string: 
grantor,               -- string: grantor of access, may be null
grantee,               -- string: grantee of access
privilege,             -- string: SELECT, INSERT, DELETE, ....
is_grantable           -- string: YES, NO
)
as
select 
cast(null as char),    -- table_cat
schemaname, tablename, colname, grantor, grantee, privilege, is_grantable
from odbc_25_41_1.odbc_col_priv
;



-- 
-- getcolumns / SQLColumns
-- get description of tables and their columns
-- 
create view getcolumns(
table_cat,             -- string: always NULL
table_schem,           -- string: 
table_name,            -- string: 
column_name,           -- string: 
data_type,             -- short : java.sql.Types p.881
type_name,             -- string: type name used by the data source
column_size,           -- int   : precision
buffer_length,         -- int   : not used
decimal_digits,        -- short : scale
num_prec_radix,        -- short : 10 for numeric datatypes, null for others
nullable,              -- short :
remarks,               -- string: empty 
column_def,            -- string: default value or NULL
sql_data_type,         -- short : not used
sql_datetime_sub,      -- short : not used
char_octet_length,     -- int   : max number of bytes (for char types)
ordinal_position,      -- int   : column sequence number
is_nullable            -- string: "yes","no",""
)
as
select 
cast(null as char),    -- table_cat
t.schemaname,          -- table_schem
t.tablename,           -- table_name
t.colname,             -- column_name
cast(                  -- data_type
case t.datatype
when  1 then  5   -- smallint
when  2 then  4   -- integer
when  3 then -5   -- bigint
when  4 then  3   -- decimal
when  5 then  6   -- float
when  6 then  8   -- double
when  8 then  
  case t.varsize
  when  0 then  1 -- char
  else         12 -- varchar
  end
when  9 then 
  case t.varsize
  when  0 then -2 -- binary
  else         -3 -- varbinary
  end
when 11 then
  case (t.specification / 256) % 64 
  when 61 then 91 -- date
  when 34 then 92 -- time
  when 58 then 93 -- timestamp
  else 2222       -- ERROR
  end
else 1111         -- other
end
as smallint),
case                   -- type_name
when t.datatype =  1 then 'smallint                        ' 
when t.datatype =  2 then 'integer                         ' 
when t.datatype =  3 then 'double integer                  ' 
when t.datatype =  4 then 'decimal                         ' 
when t.datatype =  5 then 'real                            ' 
when t.datatype =  6 then 'double precision                ' 
when t.datatype =  8 and t.varsize = 0
                     then 'char                            ' 
when t.datatype =  8 and t.varsize = 1
                     then 'varchar                         ' 
when t.datatype =  9 and t.varsize = 0
                     then 'binary                          ' 
when t.datatype =  9 and t.varsize = 1
                     then 'varbinary                       ' 
when t.datatype = 11 and (t.specification / 256) % 64 = 61
                     then 'date                            ' 
when t.datatype = 11 and (t.specification / 256) % 64 = 34
                     then 'time                            ' 
when t.datatype = 11 and (t.specification / 256) % 64 = 58
                     then 'timestamp                       ' 
when t.datatype = 12 then 'interval                        '
else                      '                                ' 
end,
cast(                  -- column_size (when converted to char)
case         -- FIXME: check all sizes here
when t.datatype =  1 then  5                    -- smallint
when t.datatype =  2 then 10                    -- integer
when t.datatype =  3 then 19                    -- double integer
when t.datatype =  4 then 31                    -- decimal
when t.datatype =  5 then  7                    -- real
when t.datatype =  6 then 15                    -- double precision
when t.datatype =  8 then  t.specification      -- char/varchar
when t.datatype =  9 then  t.specification * 2  -- binary/varbinary
when t.datatype = 11 and (t.specification / 256) % 64 = 61
                     then 10                    -- date
when t.datatype = 11 and (t.specification / 256) % 64 = 34
                     then 8 + 6 + 1             -- time
when t.datatype = 11 and (t.specification / 256) % 64 = 58
                     then 19 + 6 + 1            -- timestamp
when t.datatype = 12 then 8                     -- interval
else null
end
as integer),
cast(0 as int),        -- buffer_length, not used
cast(                  -- decimal_digits
case
when t.datatype =  4 then t.specification % 32  -- decimal
when t.datatype = 11 and (t.specification / 256) % 64 = 34
                     then t.specification % 32  -- time
when t.datatype = 11 and (t.specification / 256) % 64 = 58
                     then t.specification % 32  -- timestamp
when t.datatype = 12 then t.specification % 32  -- interval
else null
end
as smallint),
case t.datatype        -- num_prec_radix
when  1 then 10   -- smallint
when  2 then 10   -- integer
when  3 then 10   -- bigint
when  4 then 10   -- decimal
when  5 then 10   -- float
when  6 then 10   -- double
else cast(null as smallint)
end,
t.nullable,            -- nullable
cast(null as char),    -- remarks
t.column_def,          -- column_def
cast(null as smallint),-- sql_data_type     NOT IN USE (no interval in jdbc)
cast(null as smallint),-- sql_datetime_sub  NOT IN USE (no interval in jdbc)
cast(                  -- char_octet_length
case
when t.datatype =  8 then  t.specification      -- char/varchar
else                       null
end
as integer),
t.seqno,               -- ordinal_position
cast(                  -- is_nullable
case t.nullable
when 1 then 'yes'
else        'no'
end
as varchar(3))
from odbc_25_41_1.odbc_columns_def as t 
;



-- 
-- getcrossreference / SQLForeignKeys
-- get info on primary/foreign key pairs
-- NOT SUPPORTED in (current version of) HADB, return empty result
-- 
create view getcrossreference(
pktable_cat,           -- string: always NULL
pktable_schem,         -- string:
pktable_name,          -- string:
pkcolumn_name,         -- string:
fktable_cat,           -- string: always NULL
fktable_schem,         -- string:
fktable_name,          -- string:
fkcolumn_name,         -- string:
key_seq,               -- short : sequence number within FK
update_rule,           -- short : 0,1,2,3,4
delete_rule,           -- short : 0,1,2,3,4
fk_name,               -- string: identifier of FK, or NULL
pk_name,               -- string: identifier of PK, or NULL
deferrability          -- short : 5,6,7
)
as
select
cast(null as char),    -- pktable_cat
cast(null as char),    -- pktable_schem
cast(null as char),    -- pktable_name
cast(null as char),    -- pkcolumn_name
cast(null as char),    -- fktable_cat
cast(null as char),    -- fktable_schem
cast(null as char),    -- fktable_name
cast(null as char),    -- fkcolumn_name
cast(null as smallint),-- key_seq
cast(null as smallint),-- update_rule
cast(null as smallint),-- delete_rule
cast(null as char),    -- fk_name
cast(null as char),    -- pk_name
cast(null as smallint) -- deferrability
from sysroot.dual
where 1=0
;



-- 
-- getexportedkeys / SQLForeignKeys
-- get info on foreign keys
-- NOT SUPPORTED in (current version of) HADB, return empty result
-- 
create view getexportedkeys(
pktable_cat,           -- string: always NULL
pktable_schem,         -- string:
pktable_name,          -- string:
pkcolumn_name,         -- string:
fktable_cat,           -- string: always NULL
fktable_schem,         -- string:
fktable_name,          -- string:
fkcolumn_name,         -- string:
key_seq,               -- short : sequence number within FK
update_rule,           -- short : 0,1,2,3,4
delete_rule,           -- short : 0,1,2,3,4
fk_name,               -- string: identifier of FK, or NULL
pk_name,               -- string: identifier of PK, or NULL
deferrability          -- short : 5,6,7
)
as
select
cast(null as char),    -- pktable_cat
cast(null as char),    -- pktable_schem
cast(null as char),    -- pktable_name
cast(null as char),    -- pkcolumn_name
cast(null as char),    -- fktable_cat
cast(null as char),    -- fktable_schem
cast(null as char),    -- fktable_name
cast(null as char),    -- fkcolumn_name
cast(null as smallint),-- key_seq
cast(null as smallint),-- update_rule
cast(null as smallint),-- delete_rule
cast(null as char),    -- fk_name
cast(null as char),    -- pk_name
cast(null as smallint) -- deferrability
from sysroot.dual
where 1=0
;



-- 
-- getimportedkeys / SQLForeignKeys
-- get info on foreign keys
-- NOT SUPPORTED in (current version of) HADB, return empty result
-- 
create view getimportedkeys(
pktable_cat,           -- string: always NULL
pktable_schem,         -- string:
pktable_name,          -- string:
pkcolumn_name,         -- string:
fktable_cat,           -- string: always NULL
fktable_schem,         -- string:
fktable_name,          -- string:
fkcolumn_name,         -- string:
key_seq,               -- short : sequence number within FK
update_rule,           -- short : 0,1,2,3,4
delete_rule,           -- short : 0,1,2,3,4
fk_name,               -- string: identifier of FK, or NULL
pk_name,               -- string: identifier of PK, or NULL
deferrability          -- short : 5,6,7
)
as
select
cast(null as char),    -- pktable_cat
cast(null as char),    -- pktable_schem
cast(null as char),    -- pktable_name
cast(null as char),    -- pkcolumn_name
cast(null as char),    -- fktable_cat
cast(null as char),    -- fktable_schem
cast(null as char),    -- fktable_name
cast(null as char),    -- fkcolumn_name
cast(null as smallint),-- key_seq
cast(null as smallint),-- update_rule
cast(null as smallint),-- delete_rule
cast(null as char),    -- fk_name
cast(null as char),    -- pk_name
cast(null as smallint) -- deferrability
from sysroot.dual
where 1=0
;



-- 
-- getindexinfo / SQLStatistics
-- get statistical info on a table and its associated indexes
--     info about the table itself
--     info about the primary key/index
--     info about each secondary index defined for the table
-- statistical info is (currently) not available in HADB SQL,
--     so 'cardinality' and 'pages' will be return as NULL
-- 
create view getindexinfo(
table_cat,             -- string: always NULL
table_schem,           -- string: 
table_name,            -- string: 
non_unique,            -- short : SQL_TRUE / SQL_FALSE / NULL
index_qualifier,       -- string: table name or NULL
index_name,            -- string: index name or NULL
type,                  -- short : 0,1,2,3
ordinal_position,      -- short : NULL or 1..n
column_name,           -- string: column name or NULL
asc_or_desc,           -- string: "A" or "D", or NULL
cardinality,           -- int   : number of rows, or NULL
pages,                 -- int   : number of pages, or NULL
filter_condition       -- string: index filter condition, if any
)
as
select                 -- Base table information
cast(null as char),    -- table_cat
t.schemaname,          -- table_shem
t.tablename,           -- table_name
cast(null as smallint),-- non_unique
cast(null as char),    -- index_qualifier
cast(null as char),    -- index_name
cast(0    as smallint),-- type == tableIndexStatistic == SQL_TABLE_STAT
cast(null as smallint),-- ordinal_position
cast(null as char),    -- column_name
cast(null as char),    -- asc_or_desc
t.cardinality,         -- cardinality == NULL (not available in SQL)
t.pages,               -- pages       == NULL (not available in SQL)
cast(null as char)     -- filter_condition
from odbc_25_41_1.odbc_stat as t 
UNION ALL
select                 -- Primary key/index information
cast(null as char),    -- table_cat
t.schemaname,          -- table_shem
t.tablename,           -- table_name
cast(0 as smallint),   -- non_unique == false (index values must be unique)
cast(null as char),    -- index_qualifier
'PRIMARY',             -- index_name
cast(1    as smallint),-- type == tableIndexClustered == SQL_INDEX_CLUSTERED
t.seqno,               -- ordinal_position
t.colname,             -- column_name
'A',                   -- asc_or_desc
s.rowcount,            -- cardinality == NULL (not available in SQL)
s.datablocks,          -- pages       == NULL (not available in SQL)
cast(null as char)     -- filter_condition
from odbc_25_41_1.odbc_primary as t 
join odbc_25_41_1.odbc_diststat as s on t.tableid = s.tableid
UNION ALL
select                 -- Secondary index information
cast(null as char),    -- table_cat
t.schemaname,          -- table_shem
t.tablename,           -- table_name
t.non_unique,          -- non_unique
t.tablename,           -- index_qualifier
t.index_name,          -- index_name
cast(3    as smallint),-- type == tableIndexOther == SQL_INDEX_OTHER
t.seq_in_index,        -- ordinal_position
t.colname,             -- column_name
t.collate_seq,         -- asc_or_desc
s.rowcount,            -- cardinality == NULL (not available in SQL)
s.datablocks,          -- pages       == NULL (not available in SQL)
cast(null as char)     -- filter_condition
from odbc_25_41_1.odbc_index    as t 
join odbc_25_41_1.odbc_diststat as s on t.index_id = s.tableid
;



-- 
-- getprimarykeys / SQLPrimaryKeys
-- retreive the list of column names that make up the primary key
-- 
create view getprimarykeys(
table_cat,             -- string: always NULL
table_schem,           -- string: 
table_name,            -- string: 
column_name,           -- string:
key_seq,               -- short : columns sequence number, 1..n
pk_name                -- string: NULL
)
as
select
cast(null as char),    -- table_cat
schemaname,            -- table_schem
tablename,             -- table_name
colname,               -- column_name
seqno,                 -- key_seq
cast(null as char)     -- pk_name
from odbc_25_41_1.odbc_primary
;



-- 
-- getprocedurecolumns / SQLProcedureColumns
-- get in/out parameters as well as result set for stored procedure
-- NOT SUPPORTED in (current version of) HADB, return empty result
-- Why does JDBC specify ODBC2.0 versions of columns in this view,
--   when GetColumns' uses ODBC3.0 ??
-- If we choose to keep the ODBC3.0 names, 
--   the driver will have to rename some columns...
-- 
create view getprocedurecolumns(
procedure_cat,         -- string: always NULL
procedure_schem,       -- string: 
procedure_name,        -- string: 
column_name,           -- string: 
column_type,           -- short : 0,1,2,3,4,5
data_type,             -- short : java.sql.Types p.881
type_name,             -- string: type name used by the data source
column_size,           -- int   : precision in JDBC, why? re.getcolumns
buffer_length,         -- int   : length    in JDBC, why? re.getcolumns
decimal_digits,        -- short : scale     in JDBC, why? re.getcolumns
num_prec_radix,        -- short : radix     in JDBC, why? re.getcolumns
nullable,              -- short : 0,1,2
remarks                -- string: empty
)
as
select
cast(null as char),    -- procedure_cat
cast(null as char),    -- procedure_schem
cast(''   as char),    -- procedure_name
cast(''   as char),    -- column_name
cast(0    as smallint),-- column_type == procedureColumnUnknown
cast(1111 as smallint),-- data_type   == OTHER
cast(''   as char),    -- type_name
cast(null as int),     -- column_size
cast(null as int),     -- buffer_length
cast(null as smallint),-- decimal_digits
cast(null as smallint),-- num_prec_radix
cast(2    as smallint),-- nullable == procedureNullableUnknown
cast(null as char)     -- remarks
from sysroot.dual
where 1=0
;



-- 
-- getprocedures / SQLProcedures
-- retreive a list of stored procedure names
-- NOT SUPPORTED in (current version of) HADB, return empty result
-- 
create view getprocedures(
procedure_cat,         -- string: always NULL
procedure_schem,       -- string: 
procedure_name,        -- string: 
num_input_params,      -- int   : for future use
num_output_params,     -- int   : for future use
num_result_sets,       -- int   : for future use
remarks,               -- string: empty
procedure_type         -- short : 0,1,2
)
as
select
cast(null as char),    -- procedure_cat
cast(null as char),    -- procedure_schem
cast(''   as char),    -- procedure_name
cast(0    as int),     -- num_input_params
cast(0    as int),     -- num_output_params
cast(0    as int),     -- num_result_sets
cast(null as char),    -- remarks
cast(0    as smallint) -- procedure_type == ProcedureResultUnknown
from sysroot.dual
where 1=0
;



-- 
-- getschemas
-- names of all schemas (or only the visible ones??)
-- 
create view getschemas(
table_schem            -- string: 
)
as 
select 
tablename              -- table_schem
from odbc_25_41_1.odbc_tbl 
where entitytype = 2
;



-- 
-- gettableprivileges SQLTablePrivileges
-- get description of access rights for tables
-- 
create view gettableprivileges(
table_cat,             -- string: always NULL
table_schem,           -- string: 
table_name,            -- string: 
grantor,               -- string: grantor of access, may be null
grantee,               -- string: grantee of access
privilege,             -- string: SELECT, INSERT, DELETE, ....
is_grantable           -- string: YES, NO
)
as
select
cast(null as char),    -- table_cat
schemaname, tablename, grantor, grantee, privilege, is_grantable
from odbc_25_41_1.odbc_tbl_priv
;



-- 
-- gettables / SQLTables
-- retreive list of tables
-- 
create view gettables(
table_cat,             -- string: always NULL
table_schem,           -- string: 
table_name,            -- string: 
table_type,            -- string: TABLE, VIEW, ...
remarks                -- string: empty
)
as
select
cast(null as char),    -- table_cat
schemaname,            -- table_schem
tablename,             -- table_name
tbltype,               -- table_type
cast(null as char)     -- remarks
from odbc_25_41_1.odbc_tables
;



-- 
-- gettabletypes
-- get table types available
-- 
create view
gettabletypes
as
select table_type
from (values('SYSTEM TABLE'),('TABLE'),('VIEW')) as t(table_type)
;



-- 
-- gettypeinfo / SQLGetTypeInfo
-- get description of all data types supported
-- 
create view gettypeinfo(
type_name,             -- string: data source specific name for type
data_type,             -- short : java.sql.Types p.881
column_size,           -- int   : precision in JDBC, why? re.getcolumns
literal_prefix,        -- string: how to quote a literal of this type
literal_suffix,        -- string: how to quote a literal of this type
create_params,         -- string: explanation of type arguments
nullable,              -- short : 0,1,2  all types are typeNullable == 1
case_sensitive,        -- short : true/false
searchable,            -- short : 0,1,2,3 (unsearchable,like_only,
                       --                  all_except_like,searchable)
unsigned_attribute,    -- short : true/false/null
fixed_prec_scale,      -- short : money
auto_unique_value,     -- short : auto_increment
local_type_name,       -- string: native (english?) language dexcription
minimum_scale,         -- int   : minimum scale for datatype, or null
maximum_scale,         -- int   : maximum scale for datatype, or null
sql_data_type,         -- short : unused in jdbc
sql_datetime_sub,      -- short : unused in jdbc
num_prec_radix         -- short : the radix value of the datatype
)
as
select * from (values
(
'DOUBLE INTEGER'      ,-- type_name
cast(-5   as smallint),-- data_type
cast(19   as integer ),-- column_size
cast(null as char(2) ),-- literal_prefix
cast(null as char(2) ),-- literal_suffix
cast(null as char(32)),-- create_params
cast(1    as smallint),-- nullable
cast(0    as smallint),-- case_sensitive
cast(2    as smallint),-- searchable
cast(0    as smallint),-- unsigned_attribute
cast(0    as smallint),-- fixed_prec_scale
cast(0    as smallint),-- auto_unique_value
cast(null as char    ),-- local_type_name
cast(0    as integer ),-- minimum_scale
cast(0    as integer ),-- maximum_scale
cast(-5   as smallint),-- sql_data_type
cast(0    as smallint),-- sql_datetime_sub
cast(10   as smallint) -- num_prec_radix
),
('VARBINARY'        ,-3,16000,'x''','''', 'MAX LENGTH'     ,1,0,3,null,0,0,null,null,null,-3,0,null),
('BINARY'           ,-2,16000,'x''','''', 'LENGTH'         ,1,0,3,null,0,0,null,null,null,-2,0,null),
('CHAR'             , 1, 8000,'''' ,'''', 'LENGTH'         ,1,1,3,null,0,0,null,null,null, 1,0,null),
('NUMERIC'          , 2,   31,null ,null, 'PRECISION,SCALE',1,0,2,0   ,0,0,null,0   ,31  , 2,0,10  ),
('DECIMAL'          , 3,   31,null ,null, 'PRECISION,SCALE',1,0,2,0   ,0,0,null,0   ,31  , 3,0,10  ),
('INTEGER'          , 4,   10,null ,null, null             ,1,0,2,0   ,0,0,null,0   , 0  , 4,0,10  ),
('SMALLINT'         , 5,    5,null ,null, null             ,1,0,2,0   ,0,0,null,0   , 0  , 5,0,10  ),
('FLOAT'            , 6,   15,null ,null, 'PRECISION'      ,1,0,2,0   ,0,0,null,null,null, 6,0,10  ),
('REAL'             , 7,    7,null ,null, null             ,1,0,2,0   ,0,0,null,null,null, 7,0,10  ),
('DOUBLE PRECISION' , 8,   15,null ,null, null             ,1,0,2,0   ,0,0,null,null,null, 8,0,10  ),
('DATE'             ,91,   10,'''' ,'''', null             ,1,0,2,null,0,0,null,null,null, 9,0,null),
('TIME'             ,92,   15,'''' ,'''', 'PRECISION'      ,1,0,2,null,0,0,null,0   , 6  ,10,0,null),
('TIMESTAMP'        ,93,   26,'''' ,'''', 'PRECISION'      ,1,0,2,null,0,0,null,0   , 6  ,11,0,null),
('VARCHAR'          ,12, 8000,'''' ,'''', 'MAX LENGTH'     ,1,1,3,null,0,0,null,null,null,12,0,null)
)
as t(type_name,
     data_type,
     column_size,
     literal_prefix,
     literal_suffix,
     create_params,
     nullable,
     case_sensitive,
     searchable,
     unsigned_attribute,
     fixed_prec_scale,
     auto_unique_value,
     local_type_name,
     minimum_scale,
     maximum_scale,
     sql_data_type,
     sql_datetime_sub,
     num_prec_radix
)
;     


-- 
-- getudts
-- get description of all user defined data types
-- NOT SUPPORTED in (current version of) hadb, return empty result
-- 
create view getudts(
type_cat,              -- string: always NULL
type_schem,            -- string: 
type_name,             -- string: 
class_name,            -- string: 
data_type,             -- short : java.sql.Types p.881
remarks                -- string: empty
)
as
select
cast(null as char),    -- type_cat
cast(null as char),    -- type_schem
cast(null as char),    -- type_name
cast(null as char),    -- class_name
cast(null as smallint),-- data_type
cast(null as char)     -- remarks
from sysroot.dual
where 1=0
;



-- 
-- getversioncolumns / SQLSpecialColumns
-- get description of columns that ar maintained by data source automatically
-- 
create view getversioncolumns(
schemaname,            -- string: schema name   (input to getBestRowIdentifier)
tablename,             -- string: table name    (input to getBestRowIdentifier)
scope,                 -- short : 0,1,2
seqno,                 -- short : column number (extra, so we can sort on it  )
column_name,           -- string: 
data_type,             -- short : java.sql.Types p.881
type_name,             -- string: type name used by the data source
column_size,           -- int   : precision
buffer_length,         -- int   : not used
decimal_digits,        -- short : scale
pseudo_column          -- short : 0,1,2
)
as
select
schemaname,            -- schemaname
tablename,             -- tablename
cast(null as smallint),-- scope
t.seqno,               -- seqno
t.colname,             -- column_name
cast(-2   as smallint),-- data_type == binary
'binary',              -- type_name
cast(                  -- column_size (when converted to char)
2 * (t.specification % 1024)
as integer),
cast(                  -- buffer_length, not used
t.specification % 1024
as integer),
cast(null as smallint),-- decimal_digits
cast(2 as smallint)    -- pseudo_column (versionColumnPseudo)
from odbc_25_41_1.odbc_special  as t 
where t.datatype = 16
;


--
-- GRANT TO PUBLIC
--
grant select on getbestrowidentifier to public;
grant select on getcatalogs          to public;
grant select on getcolumnprivileges  to public;
grant select on getcolumns           to public;
grant select on getcrossreference    to public;
grant select on getexportedkeys      to public;
grant select on getimportedkeys      to public;
grant select on getindexinfo         to public;
grant select on getprimarykeys       to public;
grant select on getprocedurecolumns  to public;
grant select on getprocedures        to public;
grant select on getschemas           to public;
grant select on gettableprivileges   to public;
grant select on gettables            to public;
grant select on gettabletypes        to public;
grant select on gettypeinfo          to public;
grant select on getudts              to public;
grant select on getversioncolumns    to public;
