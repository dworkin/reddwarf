-- Copyright 2002 Sun Microsystems, Inc.  All rights reserved.
-- Use is subject to license terms.
--
drop view jdbc_20_41_1.getbestrowidentifier cascade;
drop view jdbc_20_41_1.getcatalogs          cascade;
drop view jdbc_20_41_1.getcolumnprivileges  cascade;
drop view jdbc_20_41_1.getcolumns           cascade;
drop view jdbc_20_41_1.getcrossreference    cascade;
drop view jdbc_20_41_1.getexportedkeys      cascade;
drop view jdbc_20_41_1.getimportedkeys      cascade;
drop view jdbc_20_41_1.getindexinfo         cascade;
drop view jdbc_20_41_1.getprimarykeys       cascade;
drop view jdbc_20_41_1.getprocedurecolumns  cascade;
drop view jdbc_20_41_1.getprocedures        cascade;
drop view jdbc_20_41_1.getschemas           cascade;
drop view jdbc_20_41_1.gettableprivileges   cascade;
drop view jdbc_20_41_1.gettables            cascade;
drop view jdbc_20_41_1.gettabletypes        cascade;
drop view jdbc_20_41_1.gettypeinfo          cascade;
drop view jdbc_20_41_1.getudts              cascade;
drop view jdbc_20_41_1.getversioncolumns    cascade;
