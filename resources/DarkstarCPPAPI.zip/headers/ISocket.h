#ifndef _ISocket_h
#define _ISocket_h

namespace Darkstar
{
	class ISocketListener;

	struct BufferDescriptor
	{
		const byte* Data;
		size_t Length;
	};

	class ISocket
	{
	public:
		virtual void SetListener(ISocketListener* pListener) = 0;
		virtual void Disconnect() = 0;
		virtual void Send(const BufferDescriptor* buffers, size_t count) = 0;
	};
}

#endif
