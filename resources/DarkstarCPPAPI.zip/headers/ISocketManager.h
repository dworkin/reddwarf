#ifndef _ISocketManager_h
#define _ISocketManager_h

namespace Darkstar
{
	class ISocket;
	class ISocketManagerListener;

	class ISocketManager
	{
	public:
		virtual ~ISocketManager() { }

		virtual void SetListener(ISocketManagerListener* pListener) = 0;
		virtual ISocket* Connect(const std::wstring& host, uint16 port) = 0;
	};
}

#endif
