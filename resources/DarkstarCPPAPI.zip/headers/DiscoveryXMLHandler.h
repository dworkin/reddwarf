#ifndef _DiscoveryXMLHandler_h
#define _DiscoveryXMLHandler_h

#include "XMLParser/ISAXHandler.h"

namespace Darkstar
{
	class IDiscoveredGame;
	class DiscoveredGame;
	class DiscoveredUserManager;

	class DiscoveryXMLHandler : public ISAXHandler
	{
	public:
		virtual std::vector<IDiscoveredGame*> GetGames() const;

	private:
		virtual void OnStartElement(const std::wstring& name, AttributeMap& attributes);
		virtual void OnEndElement(const std::wstring& name);

		std::vector<IDiscoveredGame*> mGames;

		DiscoveredGame* mGame;
		DiscoveredUserManager* mUserManager;
	};
}

#endif
